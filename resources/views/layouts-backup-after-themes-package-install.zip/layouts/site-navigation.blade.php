<div class="menus">
			<ul>
				<li class="active">
				 
				 <i class="icon-education-cap"></i>
					{{ getPhrase('educate')}} </li>
				<li>
					  
						<i class="icon-education-cap"></i>
						{{ getPhrase('enlight')}}
					 
				</li>
				<li>
					 
						<i class="icon-education-cap"></i>
					{{ getPhrase('enforce')}}
					 
				</li>
				 
			</ul>
</div>